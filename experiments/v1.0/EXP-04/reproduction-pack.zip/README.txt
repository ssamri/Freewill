Reproduction pack of a Freewill Research Lab campaign.
python -m freewill.research run EXP-04
recomputes results.json; compare results_sha256 with manifest.json.
