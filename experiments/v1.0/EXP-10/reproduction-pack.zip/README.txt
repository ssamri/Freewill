Reproduction pack of a Freewill Research Lab campaign.
python -m freewill.research run EXP-10
recomputes results.json; compare results_sha256 with manifest.json.
